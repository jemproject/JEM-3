features:
is an enhanced mod_jem_teaser with:
- without venueimage
- bigger eventimage
- choice to show with or without calendarimage
- choice to show or hide eventimage
- choice to show date or time until event
- choice to show or hide category
- choice to hide or hide venue

it's preferably to use best on side modules (with more than one events)

My uploaded eventimages have always a height of 200px.